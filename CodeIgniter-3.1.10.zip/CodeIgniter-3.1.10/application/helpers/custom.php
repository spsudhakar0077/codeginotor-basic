<?php

function add()
{
	return 10+25;
}

?>