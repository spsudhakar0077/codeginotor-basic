<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Array_helper_demo extends CI_Controller {

	
	public function index($prouct_name='')
	{

		echo "< h1>"$prouct_name " </h1>";
		$this->load->helper("array");
		
		$data['seo'] = array(
      "meta_dec"=> "I find that the harder I work, the more luck I seem to have. - Thomas Jefferson",
      "meta_key"=>"Don't stay in bed, unless you can make money in bed. - George Burns",
      "title"=>"We didn't lose the game; we just ran out of time. - Vince Lombardi"
        
);

$this->load->view('Array_helper_view',$data,FALSE);
		
	}
	
}
?>