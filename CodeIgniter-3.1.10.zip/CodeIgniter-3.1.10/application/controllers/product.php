<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class product extends CI_Controller {

	
	public function index($prouct_name='')
	{

		echo $prouct_name;
		$this->load->helper("array");
		
		

$this->load->view('product_view');
		
	}
	
}
?>