<?php


class user extends CI_Controller {

	
	
	public function index()
	{
		$this->load->model('/service');
	}
	public function test()
	{
		$this->load->model('mymodel');
		$data['array'] =$this->mymodel->person();
		
		$this->load->view('user',$data);
		
	}




}


?>