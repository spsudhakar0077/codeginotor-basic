<?php


class Mycon extends CI_Controller {

	
	
	public function index()
	{
		$this->load->library('test_lib');
        $str=$this->test_lib->test1();
echo $str;

		//$this->load->view('/service');
	}
	public function test()
	{
		$this->load->model('mmodel');
		$team =$this->mmodel->team();
		
		echo "".$team;
		
	}
    public function test1()
	{echo br(2);
		$this->load->helper('custom_helper');//givecustom_helper is manitory  store file name  
		echo add();
		//$this->load->helper('html');//config -> auto loader.php-> line $autoload['helper'] = array('html');
		echo br(2);
        
		//$this->load->model('mymodel');
		$data['array'] =$this->mymodel->person();
		
		$this->load->view('user',$data);
		
	}



}


?>