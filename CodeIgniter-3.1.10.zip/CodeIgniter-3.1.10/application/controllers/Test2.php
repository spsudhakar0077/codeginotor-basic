<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test2 extends CI_Controller {

	
	public function index()
	{
		$this->load->model('Googleapi','Google');
		$name = $this->Google->fname();
		

		echo"MyNAME=>".$name;
		echo"<br>";  

	}
	
	/*public function myindex()
	{
		$this->load->view('/service');
	}*/
}
?>