<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usercon extends CI_Controller {

	
	public function index()
	{
		$this->load->model('Usermodel');
		$data['userdetails'] = $this->Usermodel->details();
		$this->load->view('Userview',$data);
		
	}
	
	
}
?>