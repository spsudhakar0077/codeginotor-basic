<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class mmodel extends CI_model {

		public function team()
		{
          $private=$this->details();

			return"ok model good public".$private;
		}
	private function details()
		{
			return"to access via  model  private";
		}
	}
?>