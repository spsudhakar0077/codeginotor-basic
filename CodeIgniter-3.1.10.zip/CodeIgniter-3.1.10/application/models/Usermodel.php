<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usermodel extends CI_model {

		public function details()
	{
		$this->load->database();
		 
		$query = $this->db->query("SELECT * FROM user");
          // $query = $this->db->get_where('user',array('id'=>'2'));   
		 //$query = $this->db->get('user');/*   one of the method queyu  */
	     /*$this->db->select_avg('age');
           $query = $this->db->get('user');  */ //avg age table 
		
		
		$query->result_array();
	
          return $query->result_array();
	
	
	}
	}
?>