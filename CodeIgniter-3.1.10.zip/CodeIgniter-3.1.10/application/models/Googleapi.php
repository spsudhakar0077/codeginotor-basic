<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Googleapi extends CI_model {

		public function fname()
	{
		
		
		return "SUBASH R BROTHER  SUDHAKAR R";
	}
	
	
}
?>