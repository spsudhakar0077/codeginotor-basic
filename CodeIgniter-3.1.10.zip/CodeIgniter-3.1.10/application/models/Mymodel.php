<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mymodel extends CI_model {

		public function person()
	{


		// $this->load->database();  
		//comment lie using config fileto databse include the not error occured 
		//autoload.php ->inside line -->  $autoload['libraries'] = array('database');
		 
		$query = $this->db->query("SELECT * FROM user");
		//$query = $this->db->get('user', 1, 2);
          // $query = $this->db->get_where('user',array('id'=>'2'));   
		 //$query = $this->db->get('user');/*   one of the method queyu  */
	     /*$this->db->select_avg('age');
           $query = $this->db->get('user');  */ //avg age table 
		
		
		$query->result_array();
	   
	   // echo"<pre>"; 
         // print_r($query->result_array());   check the arry name value
		//echo"</pre>";

          return $query->result_array();
		
			//	return ["age"=>"21","username"=>"SUBASH"]; static meth
	}
	
	
}
?>