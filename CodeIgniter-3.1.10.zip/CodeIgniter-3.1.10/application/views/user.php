
<div class="w3-container">
  
  <table class="w3-table-all">
    <tr>
	<th> id</th>
      <th> Name</th>
      <th>AGE</th>
      <th>email</th>
	  <th>company</th>
    </tr>
	<?php   
	 foreach ($array as $key => $value )
	 {
		 
        /* echo"<tr> 	 

		 <td>".$value->id."</td> another method but not work 
		 <td>".$value->name."</td>
		 <td>".$value->age."</td>
		 <td>".$value->email."</td>
		 <td>".$value->company."</td>
		 </tr>";  */


		 echo"<tr>"; 
		 

		 echo"<td>".$value['id']."</td>";
		 echo"<td>".$value['name']."</td>";
		 echo"<td>".$value['age']."</td>";
		 echo"<td>".$value['email']."</td>";
		 echo"<td>".$value['company']."</td>";
		 echo"</tr>";
	 }
	
?>
	
	
    
  </table>
</div>

