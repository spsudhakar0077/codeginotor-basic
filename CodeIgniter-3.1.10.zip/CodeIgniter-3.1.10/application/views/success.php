<html>
<head>
<title>My Form</title>
</head>
<body>

<h3>Your form was successfully submitted!</h3>

<p><?php echo anchor('myform', 'Try it again!'); ?></p>

</body>
</html>