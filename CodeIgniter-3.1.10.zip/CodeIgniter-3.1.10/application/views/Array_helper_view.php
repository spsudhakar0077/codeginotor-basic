<?php 
 echo"<pre> SEO ";
print_r($seo);
echo"</pre>";





 ?>
<p> 1.element  </p>
<?php
echo element( "meta_dec",$seo);


?>
<p> 2.randomelement  </p>
<?php
echo random_element( $seo); 


?>
<p> 3.ements  </p>
<?php
$exp=elements(array("meta_dec","meta_key"),$seo); 
echo"<pre> SEO ";
print_r($exp);
echo"</pre>";
?>