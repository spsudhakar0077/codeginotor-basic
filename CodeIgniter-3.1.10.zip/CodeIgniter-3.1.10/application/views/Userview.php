<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container">
  
  <table class="w3-table-all">
    <tr>
	<th> id</th>
      <th> Name</th>
      <th>AGE</th>
      <th>email</th>
	  <th>company</th>
    </tr>
	<?php   
	 foreach ($userdetails as $key => $value )
	 {
		 
		 echo"<tr>";
		 
		 echo"<td>".$value['id']."</td>";
		 echo"<td>".$value['name']."</td>";
		 echo"<td>".$value['age']."</td>";
		 echo"<td>".$value['email']."</td>";
		 echo"<td>".$value['company']."</td>";
		 echo"</tr>";
	 }
	
?>
	
	
    
  </table>
</div>

</body>



</html>


<?php

/*echo"<pre>";

print_r($userdetails);
echo"</pre>";*/
?>
