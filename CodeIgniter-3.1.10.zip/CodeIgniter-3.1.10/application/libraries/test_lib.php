<?php
class test_lib{
	function test1()
	{
return "support custom libirary";
	}
}


?>